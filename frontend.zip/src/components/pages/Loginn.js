import "../../App.css";
import Formm from "../Form/Formm";

function Loginn() {
	return (
		<div>
			<Formm />
		</div>
	);
}

export default Loginn;
