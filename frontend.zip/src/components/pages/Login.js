import '../../App.css'
import Form from '../Form/Form';


function Login(){
    return(
        <div>
           <Form/> 
        </div>
    );
}

export default Login;