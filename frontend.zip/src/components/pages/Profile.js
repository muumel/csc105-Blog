import "../../App.css";
import Profileform from "../Profile/Profileform";
import ProfilePic from "../../pics/profilepic.jpg";

function Profile() {
	return (
		<div>
			<Profileform src={ProfilePic} style={{}} />
		</div>
	);
}

export default Profile;
